const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const cartSchema = new Schema({
    cart: {
        items: [{
            productId: {
                type: mongoose.Types.ObjectId,
                ref: 'Product',
                required: true
            },
            qty: {
                type: Number,
                required: true
            }
        }],
        totalPrice: Number
    }
})
const Cart = mongoose.model('carts', cartSchema);
module.exports = Cart;