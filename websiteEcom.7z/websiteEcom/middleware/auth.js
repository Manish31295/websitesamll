const jwt = require("jsonwebtoken");
module.exports = (req, res, next)=>{
    try{
        const token = req.headers.authorization.split(' ')[1];
        const decodeToken = jwt.verify(token, 'screte_key');
        const userId = decodeToken.userId;
        if(req.body.userId && req.body.userId!== userId){
            throw 'Invailed userId';
        }
        else{
            next();
        }
    }
    catch{
        res.status(401).json({
            err:new Error('Invailed request')
        })
    }
}