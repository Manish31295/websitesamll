const express = require("express");
const app = express();
const mongoose = require("mongoose");
const port = process.env.PORT || "7000";
const bodyParser = require("body-parser");
const userRouter = require("./route/userRoute");
const productRouter = require("./route/admin");
const shopRouter = require("./route/shop")
const categoryRouter = require("./route/categoery")

mongoose.connect("mongodb://localhost:27017/webdata", { useNewUrlParser: true, useUnifiedTopology: true })
mongoose.connection.on("connected", connected=>console.log(`connected to database`))
mongoose.connection.once("unconnected", unconnected=>console.log(`not connected to database`))

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use(userRouter)
app.use(productRouter)
app.use(shopRouter);
app.use(categoryRouter)

app.listen(port, ()=>{
    console.log(`server running on http://localhost:${port}`);
})