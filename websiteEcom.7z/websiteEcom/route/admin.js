const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const Product = require("../model/product");
const auth = require("../middleware/auth")


//get request get all products
router.get('/products',(req, res, next)=>{
    try{
        Product.find()
        .then(prod=>{
            res.status(200).json({
                prod
            })
        })
    }
    catch{

    }
})

//post request create products
router.post('/products', auth, async (req, res, next)=>{
    try{
        const{title, discription, price, discount} = req.body
        const productDoc = new Product({
            title:title,
            discription:discription,
            price:price,
            discount:discount
        })
       await productDoc.save()
        .then(prod=>{
            res.status(200).json({
                message:"product add successfully",
                prod
            })
        })
    }catch(err){
        throw err
    }
})

//get request for get one data by id
router.get('/products/:id', (req, res, next)=>{
    try{
        Product.findById({_id:req.params.id})
        .then(prod=>{
            res.status(200).json({
                prod
            })
        })
    }
    catch{

    }
})

//put request get product and update product 
router.put('/products/:id', (req, res, next)=>{
    try{
        Product.findOneAndUpdate({_id:req.params.id}, {
            $set:{
                title:req.body.title,
                discription:req.body.discription,
                price:req.body.price,
                discount:req.body.discount
            }
        })
        .then(prod=>{
            res.status(200).json({
                message:"update product successfully",
                prod
            })
        })
    }
    catch(err){
        throw err
    }
})

//get request and delete product by id
router.delete('/products/:id', (req, res, next)=>{
    try{
        Product.findByIdAndRemove({_id:req.params.id})
        .then(prod=>{
            res.status(200).json({
                message:"delete product",
                prod
            })
        })
    }
    catch(err){
        throw err
    }
})



module.exports = router;