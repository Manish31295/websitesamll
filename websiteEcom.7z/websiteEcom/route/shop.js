const express = require("express");;
const router = express.Router();
const Product = require("../model/product");
const mongoose = require("mongoose");
const Cart = require("../model/cart");


// get request for every user get all product
router.get("/products", (req, res, next)=>{
    try{
        Product.find()
        .then(prod=>{
            res.status(200).json({
                message:"get all products",
                prod
            })
        })
    }
    catch(err){
        throw err
    }
})
// get request for get product detail
router.get("/products/:id", (req, res, next)=>{
    try{
        Product.findById(req.params.id)
        .then(prod=>{
            res.status(200).json({
                prod
            })
        })
    }
    catch(error){
        throw err
    }
})
// get request for add to cart
router.post("/products/:id/addToCart", async (req, res, next)=>{
    const newProduct = new Cart(req.body)
    try{
        const saveProduct = await newProduct.save();
        res.status(200).json(saveProduct)
    }catch(err){
        res.status(400).json(err)
    }
})
module.exports = router;
