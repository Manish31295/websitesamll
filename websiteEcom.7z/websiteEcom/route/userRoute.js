const express = require("express")
const router = express.Router();
const User = require("../model/user")
const mongoose = require("mongoose");
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")

router.post("/register", async (req, res, next)=>{
   
        bcrypt.hash(req.body.password, 10, function(err, hash){
            if(err){
                return res.status(500).json({
                    error:err
                })
            }
            else{

                try{
                let userDoc = new User({
                    name:req.body.name,
                    email:req.body.email,
                    phone:req.body.phone,
                    password:hash
            })
          userDoc.save()
           .then(user=>{
               res.status(200).json({
                   message:"successfully register",
                   user
               })
           })
        }
        catch(err){
            throw err 
        }
            }
        })   
})

//login
router.post("/login", (req, res, next)=>{
    User.find({email:req.body.email})
    .exec()
    .then(user=>{
        if(user.length < 1){
            return res.status(401).json({
                message:"not user"
            })
        }else{
            bcrypt.compare(req.body.password, user[0].password, (errr, result)=>{
                if(!result){
                    return res.status(401).json({
                        message:"password matching failed"
                    })
                }
                if(result){
                    const token = jwt.sign({
                        name:user[0].name,
                        email:user[0].email,
                        phone:user[0].phone,
                        password:user[0].password
                    },
                    'screte_key', 
                    {
                        expiresIn: "24h"
                    }
                    );
                    res.status(200).json({
                        name:user[0].name,
                        email:user[0].email,
                        phone:user[0].phone,
                        token:token
                    })
                }
            })
          
        }
    })
   
    .catch(err=>{
        res.status(404).json({
            err
        })
    })
    
})

module.exports = router;