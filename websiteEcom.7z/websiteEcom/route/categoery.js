const express = require("express");
const router = express.Router();
const category = require("../model/categoery");
const slugify = require("slugify")
const auth = require("../middleware/auth")


router.post('/category/create', auth, (req, res, next)=>{
    try{
        const categoryDoc = {
            name: req.body.name,
            slug: slugify(req.body.name)
        }
        if(req.body.parentId){
            categoryDoc.parentId = req.body.parentId;
        }
        const cate = new category(categoryDoc);
        cate.save((error, category)=>{
            if(error) return res.status(400).json({
                message:"not add category",
                error
            })
            if(category){
                return res.status(201).json({
                    message:"add category",
                    category
                })
            }
        })
    }
    catch(error){
        throw error
    }
})


module.exports = router;